-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Ven 15 Décembre 2023 à 17:04
-- Version du serveur: 4.1.22
-- Version de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de données: `zanimo`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `adminid` int(11) NOT NULL auto_increment,
  `adminname` varchar(20) NOT NULL default '',
  `email` varchar(20) NOT NULL default '',
  `password` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`adminid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `admin`
--

INSERT INTO `admin` (`adminid`, `adminname`, `email`, `password`) VALUES
(1, 'sysy', 'admin@gmail.com', 'admin'),
(2, 'annous', 'admin2@gmail.com', 'sysy'),
(3, 'islem', 'admin1@gmail.com', 'ojji'),
(4, 'islem', 'admin1@gmail.com', 'jjjj');

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `idar` int(11) NOT NULL auto_increment,
  `libelle` varchar(20) NOT NULL default '',
  `qty` varchar(20) NOT NULL default '',
  `desc` varchar(20) NOT NULL default '',
  `type` varchar(20) NOT NULL default '',
  `idadmin` int(11) NOT NULL default '0',
  `prix` double NOT NULL default '0',
  PRIMARY KEY  (`idar`),
  KEY `idadmin` (`idadmin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `article`
--

INSERT INTO `article` (`idar`, `libelle`, `qty`, `desc`, `type`, `idadmin`, `prix`) VALUES
(1, 'canicha', '29', 'à manger', 'aliments', 1, 20.8),
(2, 'shampooing', '22', 'pour la bonne humeur', 'hygiene', 1, 30.999),
(3, 'Niche', '4', 'pour tout les animau', 'pour dormir', 1, 40),
(4, 'jnjnj', '2', 'à mangerrr', 'aliments', 2, 12);

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `ref` int(11) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL default '',
  `idar` int(11) NOT NULL default '0',
  PRIMARY KEY  (`ref`),
  KEY `idar` (`idar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `category`
--


-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE IF NOT EXISTS `commande` (
  `refcom` int(11) NOT NULL auto_increment,
  `date` varchar(20) NOT NULL default '',
  `idar` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`refcom`),
  KEY `idar` (`idar`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `commande`
--


-- --------------------------------------------------------

--
-- Structure de la table `panier`
--

CREATE TABLE IF NOT EXISTS `panier` (
  `idp` int(11) NOT NULL auto_increment,
  `userid` int(11) NOT NULL default '0',
  `idar` int(11) NOT NULL default '0',
  `qty` int(11) NOT NULL default '0',
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`idp`),
  KEY `userid` (`userid`,`idar`),
  KEY `userid_2` (`userid`),
  KEY `idar` (`idar`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Contenu de la table `panier`
--

INSERT INTO `panier` (`idp`, `userid`, `idar`, `qty`, `date`) VALUES
(17, 1, 3, 4, '2023-12-11 14:21:41'),
(18, 1, 2, 5, '2023-12-11 15:01:38'),
(19, 1, 1, 4, '2023-12-12 08:46:50');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `userid` int(11) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL default '',
  `email` varchar(20) NOT NULL default '',
  `password` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`userid`, `username`, `email`, `password`) VALUES
(1, 'chebbi sirine', 'sirinechebbi85@gmail', 'azert'),
(2, 'Saidi Abir', 'saidiabir@gmail.com', 'azerty'),
(3, 'Anas Ben Esghaier', 'anas@gmail.com', 'sysy'),
(4, 'chebbi sofien', 'sofien@gmail.com', '0000'),
(8, 'hamady', 'admin1@gmail.com', 'azerty'),
(9, 'annous', 'annous@gmail.com', 'sysy'),
(10, '0', 'aa', 'aa@aa.aa'),
(11, 'kk', 'k@jn.jj', 'aa');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `article_ibfk_1` FOREIGN KEY (`idadmin`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `category`
--
ALTER TABLE `category`
  ADD CONSTRAINT `category_ibfk_1` FOREIGN KEY (`idar`) REFERENCES `article` (`idar`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`idar`) REFERENCES `article` (`idar`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `commande_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `panier`
--
ALTER TABLE `panier`
  ADD CONSTRAINT `panier_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `panier_ibfk_2` FOREIGN KEY (`idar`) REFERENCES `article` (`idar`) ON DELETE CASCADE ON UPDATE CASCADE;
